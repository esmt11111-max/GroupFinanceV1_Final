package com.groupfinance.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.os.Bundle;
import android.os.Build;
import android.webkit.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.print.*;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import android.graphics.Color;
import java.util.*;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,91,145));
        getWindow().setNavigationBarColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,247,251));
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try { startActivityForResult(p.createIntent(), FILE_CHOOSER); return true; }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this,"تعذر فتح مدير الملفات",Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType == null ? "application/json" : mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                req.setTitle("نسخة احتياطية للنظام المالي");
                req.setDescription("جاري حفظ نسخة البيانات في مجلد Downloads");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "نسخة_احتياطية_النظام_المالي.json");
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this, "بدأ تنزيل النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "تعذر تنزيل الملف", Toast.LENGTH_SHORT).show(); }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface public void shareMemberPdf(String html, String filename) {
            runOnUiThread(() -> createAndSharePdf(html, filename));
        }
    }

    private void createAndSharePdf(String html, String filename) {
        final WebView printView = new WebView(this);
        printView.getSettings().setJavaScriptEnabled(false);
        printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        printView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                final File dir = new File(getCacheDir(), "shared_pdfs");
                if (!dir.exists()) dir.mkdirs();
                final File pdf = new File(dir, filename.replaceAll("[^\\p{L}\\p{N}._-]", "_") + (filename.toLowerCase(Locale.ROOT).endsWith(".pdf") ? "" : ".pdf"));
                final PrintDocumentAdapter adapter = printView.createPrintDocumentAdapter("GroupFinance");
                adapter.onLayout(null, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build(), null, new PrintDocumentAdapter.LayoutResultCallback() {
                    @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                        try {
                            ParcelFileDescriptor pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE);
                            adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, null, new PrintDocumentAdapter.WriteResultCallback() {
                                @Override public void onWriteFinished(PageRange[] pages) {
                                    try { pfd.close(); } catch (Exception ignored) {}
                                    sharePdf(pdf);
                                }
                                @Override public void onWriteFailed(CharSequence error) { try { pfd.close(); } catch (Exception ignored) {} Toast.makeText(MainActivity.this, "تعذر إنشاء ملف PDF", Toast.LENGTH_SHORT).show(); }
                            });
                        } catch (Exception e) { Toast.makeText(MainActivity.this, "تعذر إنشاء ملف PDF", Toast.LENGTH_SHORT).show(); }
                    }
                    @Override public void onLayoutFailed(CharSequence error) { Toast.makeText(MainActivity.this, "تعذر تجهيز التقرير", Toast.LENGTH_SHORT).show(); }
                }, null);
            }
        });
    }

    private void sharePdf(File pdf) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pdf);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة ملف العضو PDF"));
        } catch (Exception e) { Toast.makeText(this, "تعذر مشاركة ملف PDF", Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
