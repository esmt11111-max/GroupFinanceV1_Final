package com.groupfinance.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.os.Bundle;
import android.os.Build;
import android.content.res.Configuration;
import android.webkit.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.widget.Toast;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Environment;
import android.Manifest;
import android.content.pm.PackageManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;

    private class AndroidBridge {
        @JavascriptInterface
        public boolean saveBackup(String json, String filename) {
            return saveBackupFile(json, filename);
        }

        @JavascriptInterface
        public void openBackupPicker() {
            runOnUiThread(() -> openBackupPickerNative());
        }

        @JavascriptInterface
        public void printPage(String title) {
            runOnUiThread(() -> printCurrentPage(title == null ? "GroupFinance" : title));
        }

        @JavascriptInterface
        public void sharePdf(String title) {
            runOnUiThread(() -> createAndSharePdf(title == null ? "GroupFinance" : title));
        }
    }

    private boolean saveBackupFile(String json, String filename) {
        try {
            String safeName = (filename == null || filename.trim().isEmpty()) ? "GroupFinance_Backup.gfbak" : filename;
            if (!safeName.toLowerCase(Locale.ROOT).endsWith(".gfbak")) safeName += ".gfbak";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("تعذر إنشاء ملف النسخة الاحتياطية");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("تعذر فتح ملف النسخة الاحتياطية");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2002);
                    Toast.makeText(this, "اسمح للتطبيق بالوصول إلى التخزين ثم اضغط تنزيل النسخة الاحتياطية مرة أخرى", Toast.LENGTH_LONG).show();
                    return false;
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد Downloads");
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }
            Toast.makeText(this, "تم حفظ النسخة الاحتياطية في مجلد Downloads", Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void openBackupPickerNative() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/octet-stream");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, FILE_CHOOSER);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح اختيار ملف النسخة الاحتياطية", Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "backup.gfbak" : last;
    }

    private String readTextFile(Uri uri) throws IOException {
        try (java.io.InputStream in = getContentResolver().openInputStream(uri);
             java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
            if (in == null) throw new IOException("تعذر قراءة ملف النسخة الاحتياطية");
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private void deliverBackupToWeb(Uri uri) {
        try {
            String name = getDisplayName(uri);
            if (!name.toLowerCase(Locale.ROOT).endsWith(".gfbak")) {
                Toast.makeText(this, "اختر ملف النسخة الاحتياطية .gfbak فقط", Toast.LENGTH_LONG).show();
                return;
            }
            String text = readTextFile(uri);
            String escaped = org.json.JSONObject.quote(text);
            webView.evaluateJavascript("window.receiveNativeBackup(" + escaped + ");", null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة النسخة الاحتياطية: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void printCurrentPage(String title) {
        try {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            if (pm == null) throw new IOException("خدمة الطباعة غير متاحة");
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(title);
            pm.print(title, adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("groupfinance", "GroupFinance", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build());
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح الطباعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void createAndSharePdf(String title) {
        webView.post(() -> {
            File pdf = null;
            ParcelFileDescriptor pfd = null;
            try {
                File dir = new File(getCacheDir(), "pdf");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new IOException("تعذر إنشاء مجلد PDF");
                }

                String safe = title == null ? "GroupFinance_Report"
                        : title.replaceAll("[^\\p{L}\\p{N}._-]+", "_");
                if (safe.isEmpty()) safe = "GroupFinance_Report";

                pdf = new File(dir, safe + "_" + System.currentTimeMillis() + ".pdf");

                /*
                 * IMPORTANT:
                 * Do NOT draw the WebView onto android.graphics.pdf.PdfDocument.
                 * That approach rasterizes the WebView and produces a PDF made from
                 * screenshots/images. Instead, use WebView's native PrintDocumentAdapter.
                 * Chromium lays out the HTML as a real printable document, preserving
                 * selectable/searchable text and automatically creating A4 pages.
                 */
                final PrintDocumentAdapter adapter =
                        webView.createPrintDocumentAdapter(safe);

                final PrintAttributes attributes = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(new PrintAttributes.Resolution(
                                "groupfinance_pdf", "GroupFinance PDF", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();

                pfd = ParcelFileDescriptor.open(
                        pdf,
                        ParcelFileDescriptor.MODE_CREATE
                                | ParcelFileDescriptor.MODE_TRUNCATE
                                | ParcelFileDescriptor.MODE_READ_WRITE
                );

                final File finalPdf = pdf;
                final ParcelFileDescriptor finalPfd = pfd;

                adapter.onLayout(
                        null,
                        attributes,
                        null,
                        new PrintDocumentAdapter.LayoutResultCallback() {
                            @Override
                            public void onLayoutFinished(
                                    PrintDocumentInfo info, boolean changed) {
                                if (info == null) {
                                    try { finalPfd.close(); } catch (Exception ignored) {}
                                    if (finalPdf.exists()) finalPdf.delete();
                                    finishNativePrintView(title);
                                    Toast.makeText(
                                            MainActivity.this,
                                            "تعذر تجهيز صفحات PDF",
                                            Toast.LENGTH_LONG
                                    ).show();
                                    return;
                                }

                                adapter.onWrite(
                                        new PageRange[]{PageRange.ALL_PAGES},
                                        finalPfd,
                                        new CancellationSignal(),
                                        new PrintDocumentAdapter.WriteResultCallback() {
                                            @Override
                                            public void onWriteFinished(PageRange[] pages) {
                                                try { finalPfd.close(); } catch (Exception ignored) {}

                                                if (!finalPdf.exists() || finalPdf.length() <= 0) {
                                                    if (finalPdf.exists()) finalPdf.delete();
                                                    finishNativePrintView(title);
                                                    Toast.makeText(
                                                            MainActivity.this,
                                                            "تم إنشاء PDF فارغ",
                                                            Toast.LENGTH_LONG
                                                    ).show();
                                                    return;
                                                }

                                                closeAndShare(finalPdf, title);
                                            }

                                            @Override
                                            public void onWriteFailed(CharSequence error) {
                                                try { finalPfd.close(); } catch (Exception ignored) {}
                                                if (finalPdf.exists()) finalPdf.delete();
                                                finishNativePrintView(title);
                                                Toast.makeText(
                                                        MainActivity.this,
                                                        "تعذر كتابة PDF: " +
                                                                (error == null ? "خطأ غير معروف" : error),
                                                        Toast.LENGTH_LONG
                                                ).show();
                                            }

                                            @Override
                                            public void onWriteCancelled() {
                                                try { finalPfd.close(); } catch (Exception ignored) {}
                                                if (finalPdf.exists()) finalPdf.delete();
                                                finishNativePrintView(title);
                                                Toast.makeText(
                                                        MainActivity.this,
                                                        "تم إلغاء إنشاء PDF",
                                                        Toast.LENGTH_SHORT
                                                ).show();
                                            }
                                        }
                                );
                            }

                            @Override
                            public void onLayoutFailed(CharSequence error) {
                                try { finalPfd.close(); } catch (Exception ignored) {}
                                if (finalPdf.exists()) finalPdf.delete();
                                finishNativePrintView(title);
                                Toast.makeText(
                                        MainActivity.this,
                                        "تعذر تجهيز PDF: " +
                                                (error == null ? "خطأ غير معروف" : error),
                                        Toast.LENGTH_LONG
                                ).show();
                            }

                            @Override
                            public void onLayoutCancelled() {
                                try { finalPfd.close(); } catch (Exception ignored) {}
                                if (finalPdf.exists()) finalPdf.delete();
                                finishNativePrintView(title);
                                Toast.makeText(
                                        MainActivity.this,
                                        "تم إلغاء تجهيز PDF",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        },
                        null
                );

            } catch (Exception e) {
                if (pfd != null) {
                    try { pfd.close(); } catch (Exception ignored) {}
                }
                if (pdf != null && pdf.exists()) pdf.delete();
                finishNativePrintView(title);
                Toast.makeText(
                        MainActivity.this,
                        "تعذر إنشاء ملف PDF: " + e.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    private void finishNativePrintView(String title) {
        if (webView == null) return;
        String viewId;
        if (title != null && title.startsWith("كشف العضو")) {
            viewId = "memberDetail";
        } else if (title != null && title.startsWith("اجتماع")) {
            viewId = "meetingDetail";
        } else {
            viewId = "reports";
        }
        webView.evaluateJavascript("finishPrintView('" + viewId + "')", null);
    }

    private void closeAndShare(File pdf, String title) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pdf);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, title);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "مشاركة التقرير PDF"));
            finishNativePrintView(title);
        } catch (Exception e) {
            finishNativePrintView(title);
            Toast.makeText(this, "تعذر مشاركة ملف PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,91,145));
        getWindow().setNavigationBarColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,247,251));
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/octet-stream");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, FILE_CHOOSER);
                    return true;
                                } catch (Exception e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this,"تعذر فتح مدير الملفات",Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType == null ? "application/octet-stream" : mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                req.setTitle("نسخة احتياطية للنظام المالي");
                req.setDescription("جاري حفظ نسخة البيانات في مجلد Downloads");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "GroupFinance_Backup.gfbak");
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this, "بدأ تنزيل النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "تعذر تنزيل الملف", Toast.LENGTH_SHORT).show(); }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (webView != null) { webView.requestLayout(); webView.invalidate(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    if (takeFlags != 0) getContentResolver().takePersistableUriPermission(uri, takeFlags);
                } catch (Exception ignored) {}
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(new Uri[]{uri});
                    fileCallback = null;
                } else {
                    deliverBackupToWeb(uri);
                }
            } else if (fileCallback != null) {
                fileCallback.onReceiveValue(null);
                fileCallback = null;
            }
        }
    }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) { webView.stopLoading(); webView.destroy(); } super.onDestroy(); }
}
