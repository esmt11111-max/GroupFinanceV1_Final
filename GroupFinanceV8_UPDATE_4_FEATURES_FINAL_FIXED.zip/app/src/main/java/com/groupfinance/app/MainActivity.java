package com.groupfinance.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.os.Bundle;
import android.os.Build;
import android.content.res.Configuration;
import android.webkit.*;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.widget.Toast;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Environment;
import android.Manifest;
import android.content.pm.PackageManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.PageRange;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;

    private class AndroidBridge {
        @JavascriptInterface
        public boolean saveBackup(String json, String filename) {
            return saveBackupFile(json, filename);
        }

        @JavascriptInterface
        public void printPage(String title) {
            runOnUiThread(() -> printCurrentPage(title == null ? "GroupFinance" : title));
        }

        @JavascriptInterface
        public void sharePdf(String title) {
            runOnUiThread(() -> createAndSharePdf(title == null ? "GroupFinance" : title));
        }
    }

    private boolean saveBackupFile(String json, String filename) {
        try {
            String safeName = (filename == null || filename.trim().isEmpty()) ? "GroupFinance_Backup.gfbak" : filename;
            if (!safeName.toLowerCase(Locale.ROOT).endsWith(".gfbak")) safeName += ".gfbak";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("تعذر إنشاء ملف النسخة الاحتياطية");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("تعذر فتح ملف النسخة الاحتياطية");
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
                ContentValues done = new ContentValues();
                done.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, done, null, null);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2002);
                    Toast.makeText(this, "اسمح للتطبيق بالوصول إلى التخزين ثم اضغط تنزيل النسخة الاحتياطية مرة أخرى", Toast.LENGTH_LONG).show();
                    return false;
                }
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("تعذر إنشاء مجلد Downloads");
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }
            Toast.makeText(this, "تم حفظ النسخة الاحتياطية في مجلد Downloads", Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "تعذر حفظ النسخة الاحتياطية: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void printCurrentPage(String title) {
        try {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            if (pm == null) throw new IOException("خدمة الطباعة غير متاحة");
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(title);
            pm.print(title, adapter, new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("groupfinance", "GroupFinance", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build());
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح الطباعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void createAndSharePdf(String title) {
        webView.post(() -> {
            try {
                File dir = new File(getCacheDir(), "pdf");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new IOException("تعذر إنشاء مجلد PDF");
                }

                String safe = title == null ? "GroupFinance_Report"
                        : title.replaceAll("[^\\p{L}\\p{N}._-]+", "_");
                if (safe.isEmpty()) safe = "GroupFinance_Report";

                File pdf = new File(dir, safe + "_" + System.currentTimeMillis() + ".pdf");

                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(safe);
                PrintAttributes attributes = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setResolution(new PrintAttributes.Resolution(
                                "groupfinance_pdf", "GroupFinance PDF", 300, 300))
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();

                new android.print.PdfPrint(attributes).print(adapter, pdf,
                        new android.print.PdfPrint.Callback() {
                            @Override
                            public void onSuccess(File finalPdf) {
                                closeAndShare(finalPdf, title);
                            }

                            @Override
                            public void onFailure(String message) {
                                finishNativePrintView(title);
                                Toast.makeText(
                                        MainActivity.this,
                                        "تعذر إنشاء ملف PDF: " + message,
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        });
            } catch (Exception e) {
                finishNativePrintView(title);
                Toast.makeText(
                        this,
                        "تعذر إنشاء ملف PDF: " + e.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    private void finishNativePrintView(String title) {
        if (webView == null) return;
        String viewId;
        if (title != null && title.startsWith("كشف العضو")) {
            viewId = "memberDetail";
        } else if (title != null && title.startsWith("اجتماع")) {
            viewId = "meetingDetail";
        } else {
            viewId = "reports";
        }
        webView.evaluateJavascript("finishPrintView('" + viewId + "')", null);
    }

    private void closeAndShare(File pdf, String title) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pdf);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, title);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "مشاركة التقرير PDF"));
            finishNativePrintView(title);
        } catch (Exception e) {
            finishNativePrintView(title);
            Toast.makeText(this, "تعذر مشاركة ملف PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,91,145));
        getWindow().setNavigationBarColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,247,251));
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= 21) s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try { startActivityForResult(p.createIntent(), FILE_CHOOSER); return true; }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this,"تعذر فتح مدير الملفات",Toast.LENGTH_SHORT).show(); return false; }
            }
        });
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                req.setMimeType(mimeType == null ? "application/octet-stream" : mimeType);
                req.addRequestHeader("User-Agent", userAgent);
                req.setTitle("نسخة احتياطية للنظام المالي");
                req.setDescription("جاري حفظ نسخة البيانات في مجلد Downloads");
                req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, "GroupFinance_Backup.gfbak");
                ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
                Toast.makeText(this, "بدأ تنزيل النسخة الاحتياطية", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "تعذر تنزيل الملف", Toast.LENGTH_SHORT).show(); }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (webView != null) { webView.requestLayout(); webView.invalidate(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }
    @Override public void onBackPressed() { if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (webView != null) { webView.stopLoading(); webView.destroy(); } super.onDestroy(); }
}
