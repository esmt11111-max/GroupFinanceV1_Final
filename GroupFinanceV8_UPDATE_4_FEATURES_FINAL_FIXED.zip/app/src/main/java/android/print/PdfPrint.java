package android.print;

import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.IOException;

/**
 * Internal helper used by GroupFinance to export a WebView through Android's
 * native PrintDocumentAdapter as a real, selectable-text PDF.
 *
 * This class intentionally lives in android.print so it can construct the
 * package-private PrintDocumentAdapter callback classes exposed by the Android
 * printing API.
 */
public final class PdfPrint {
    public interface Callback {
        void onSuccess(File pdf);
        void onFailure(String message);
    }

    private final PrintAttributes printAttributes;

    public PdfPrint(PrintAttributes printAttributes) {
        this.printAttributes = printAttributes;
    }

    public void print(final PrintDocumentAdapter printAdapter,
                      final File outputFile,
                      final Callback callback) {
        if (printAdapter == null) {
            if (callback != null) callback.onFailure("PrintDocumentAdapter غير متاح");
            return;
        }

        try {
            File parent = outputFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("تعذر إنشاء مجلد PDF");
            }
            if (!outputFile.exists() && !outputFile.createNewFile()) {
                throw new IOException("تعذر إنشاء ملف PDF");
            }

            final ParcelFileDescriptor pfd = ParcelFileDescriptor.open(
                    outputFile,
                    ParcelFileDescriptor.MODE_CREATE
                            | ParcelFileDescriptor.MODE_TRUNCATE
                            | ParcelFileDescriptor.MODE_READ_WRITE
            );

            printAdapter.onLayout(
                    null,
                    printAttributes,
                    null,
                    new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override
                        public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                            if (info == null) {
                                finishFailure(pfd, outputFile, callback, "تعذر تجهيز صفحات PDF");
                                return;
                            }

                            printAdapter.onWrite(
                                    new PageRange[]{PageRange.ALL_PAGES},
                                    pfd,
                                    new CancellationSignal(),
                                    new PrintDocumentAdapter.WriteResultCallback() {
                                        @Override
                                        public void onWriteFinished(PageRange[] pages) {
                                            closeQuietly(pfd);
                                            if (!outputFile.exists() || outputFile.length() <= 0) {
                                                deleteQuietly(outputFile);
                                                if (callback != null) callback.onFailure("تم إنشاء PDF فارغ");
                                                return;
                                            }
                                            if (callback != null) callback.onSuccess(outputFile);
                                        }

                                        @Override
                                        public void onWriteFailed(CharSequence error) {
                                            String message = error == null ? "تعذر كتابة PDF" : error.toString();
                                            finishFailure(pfd, outputFile, callback, message);
                                        }

                                        @Override
                                        public void onWriteCancelled() {
                                            finishFailure(pfd, outputFile, callback, "تم إلغاء إنشاء PDF");
                                        }
                                    }
                            );
                        }

                        @Override
                        public void onLayoutFailed(CharSequence error) {
                            String message = error == null ? "تعذر تجهيز PDF" : error.toString();
                            finishFailure(pfd, outputFile, callback, message);
                        }

                        @Override
                        public void onLayoutCancelled() {
                            finishFailure(pfd, outputFile, callback, "تم إلغاء تجهيز PDF");
                        }
                    },
                    null
            );
        } catch (Exception e) {
            deleteQuietly(outputFile);
            if (callback != null) {
                callback.onFailure(e.getMessage() == null ? "خطأ غير معروف" : e.getMessage());
            }
        }
    }

    private static void finishFailure(ParcelFileDescriptor pfd,
                                      File outputFile,
                                      Callback callback,
                                      String message) {
        closeQuietly(pfd);
        deleteQuietly(outputFile);
        if (callback != null) callback.onFailure(message);
    }

    private static void closeQuietly(ParcelFileDescriptor pfd) {
        if (pfd == null) return;
        try { pfd.close(); } catch (Exception ignored) {}
    }

    private static void deleteQuietly(File file) {
        if (file == null) return;
        try { if (file.exists()) file.delete(); } catch (Exception ignored) {}
    }
}
